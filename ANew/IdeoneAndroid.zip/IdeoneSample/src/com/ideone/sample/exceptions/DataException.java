package com.ideone.sample.exceptions;

public class DataException extends Exception {
	private static final long serialVersionUID = 1L;
	public DataException(String string) {
		super(string);
	}
}
