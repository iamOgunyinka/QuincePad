/**
 * Represents data returned by getSubmissionStatus method.
 */
public class IdeoneSubmissionStatus {
    public Integer status;
    public Integer result;
}
