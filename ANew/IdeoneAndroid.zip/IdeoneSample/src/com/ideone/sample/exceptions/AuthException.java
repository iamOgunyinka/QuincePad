package com.ideone.sample.exceptions;

public class AuthException extends Exception {
	private static final long serialVersionUID = 1L;
}
