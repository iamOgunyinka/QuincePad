package com.ideone.sample;
public class IdeoneSubmissionStatus {
    public Integer status;
    public Integer result;
}